#pragma once

#include <Arduino.h>
#include <functional>

class AsyncUDPPacket {
public:
  uint8_t* data() { return nullptr; }
  IPAddress remoteIP() const { return IPAddress(); }
  uint16_t localPort() const { return 0; }
};

class AsyncUDP {
public:
  bool listen(uint16_t) { return false; }
  bool listenMulticast(IPAddress, uint16_t) { return false; }
  void onPacket(std::function<void(AsyncUDPPacket)> ) {}
};
