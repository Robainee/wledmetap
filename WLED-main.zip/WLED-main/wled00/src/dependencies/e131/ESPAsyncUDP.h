#pragma once

#include <Arduino.h>
#include <IPAddress.h>
#include <functional>

class AsyncUDPPacket {
public:
  const uint8_t* data() const { return nullptr; }
  size_t length() const { return 0; }
  IPAddress remoteIP() const { return IPAddress(); }
  uint16_t remotePort() const { return 0; }
  uint16_t localPort() const { return 0; }
};

class AsyncUDP {
public:
  bool listen(uint16_t) { return false; }
  bool listen(IPAddress, uint16_t) { return false; }
  bool listenMulticast(IPAddress, uint16_t) { return false; }
  void onPacket(std::function<void(AsyncUDPPacket)>) {}
  size_t writeTo(const uint8_t*, size_t, IPAddress, uint16_t) { return 0; }
};
