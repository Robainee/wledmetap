Trying to make a 700KB wled file, dont mind me

